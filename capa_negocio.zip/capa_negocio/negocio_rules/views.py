from negocio_rules import app
from capa_datos import data
from flask import request, jsonify

@app.route("/registrar_venta", methods=['POST', 'GET'])
def registrar_venta():
    data.registrar_venta(request.args.get("fecha"),request.args.get("cantidad"),request.args.get("silla"),request.args.get("conferencia"))
    return

@app.route("/obtener_sillas", methods=['POST', 'GET'])
def obtener_sillas():
    sillas = data.obtener_sillas()
    result_json = []
    for silla in sillas:
        cu = {
            "id": silla.id,
            "tipo": silla.tipo,
            "precio": silla.precio,
        }
        result_json.append(cu)
    return jsonify(sillas=result_json)


@app.route("/obtener_conferencias", methods=['POST', 'GET'])
def obtener_conferencias():
    conferencias = data.obtener_conferencias()
    result_json = []
    for conferencia in conferencias:
        cu = {
            "id": conferencia.id,
            "tipo": conferencia.nombre,
            "precio": conferencia.precio,
        }
        result_json.append(cu)
    return jsonify(conferencias=result_json)


'''
@app.route("/add_conferencia", methods=['POST', 'GET'])
def add_conferencia():
    data.add_conferencia(request.args.get("nombre"),request.args.get("descripcion"),request.args.get("fecha"),
                         request.args.get("precio"))
    return

@app.route("/add_evento", methods=['POST', 'GET'])
def add_evento():
    data.add_evento(request.args.get("nombre"),request.args.get("tipo"))
    return

@app.route("/add_silla", methods=['POST', 'GET'])
def add_silla():
    data.add_silla(request.args.get("tipo"))
    return
'''